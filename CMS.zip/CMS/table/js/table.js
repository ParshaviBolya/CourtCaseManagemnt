$(document).ready(function () {
    $('#dtBasicExample').DataTable({
    "searching": true // false to disable search (or any other option)
    });
    $('.dataTables_length').addClass('bs-select');
    });