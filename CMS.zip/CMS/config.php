<?php
   define('DB_SERVER', 'sql12.freemysqlhosting.net');
   define('DB_USERNAME', 'sql12320044');
   define('DB_PASSWORD', '184Tzn2sat');
   define('DB_DATABASE', 'sql12320044');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>